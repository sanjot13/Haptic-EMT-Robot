# Enum ControllerInputType

## Overview / Purpose

Enumeration ControllerInputType

|Enumerator|Value|Description|
|----------|-----|-----------|
|UNSPECIFIED\_CONTROLLER\_INPUT\_TYPE|0|Unspecified controller input type|
|ANALOG|1|Analog controller input type|
|DIGITAL|2|Digital controller input type|

**Parent topic:** [Base \(Python\)](../../summary_pages/Base.md)

