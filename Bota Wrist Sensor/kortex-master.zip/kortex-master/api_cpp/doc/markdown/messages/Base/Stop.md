# class Stop

**Parent topic:** [Base \(C++\)](../../summary_pages/Base.md)

