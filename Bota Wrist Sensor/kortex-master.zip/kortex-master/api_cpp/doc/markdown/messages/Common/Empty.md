# class Empty

**Parent topic:** [Common \(C++\)](../../summary_pages/Common.md)

