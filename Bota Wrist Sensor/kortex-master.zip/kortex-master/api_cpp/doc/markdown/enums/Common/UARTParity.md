# enum UARTParity

## Overview / Purpose

Enumeration UARTParity

|Enumerator|Value|Description|
|----------|-----|-----------|
|UART\_PARITY\_UNSPECIFIED|0|Unspecified UART parity|
|UART\_PARITY\_NONE|1|No parity|
|UART\_PARITY\_ODD|2|Odd parity|
|UART\_PARITY\_EVEN|3|Even parity|

**Parent topic:** [Common \(C++\)](../../summary_pages/Common.md)

