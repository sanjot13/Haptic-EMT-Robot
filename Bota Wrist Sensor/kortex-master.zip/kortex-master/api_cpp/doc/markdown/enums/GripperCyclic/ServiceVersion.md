# enum ServiceVersion

## Overview / Purpose

Enumeration ServiceVersion

|Enumerator|Value|Description|
|----------|-----|-----------|
|RESERVED\_0|0| |
|CURRENT\_VERSION|1|Current Version|

**Parent topic:** [GripperCyclic \(C++\)](../../summary_pages/GripperCyclic.md)

