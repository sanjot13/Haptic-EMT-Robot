# enum ServiceVersion

## Overview / Purpose

Enumeration ServiceVersion

|Enumerator|Value|Description|
|----------|-----|-----------|
|RESERVED\_0|0|Reserved|
|CURRENT\_VERSION|1|Current version|

**Parent topic:** [ActuatorCyclic \(C++\)](../../summary_pages/ActuatorCyclic.md)

