# enum EthernetDevice

## Overview / Purpose

Enumeration EthernetDevice

|Enumerator|Value|Description|
|----------|-----|-----------|
|ETHERNET\_DEVICE\_UNSPECIFIED|0|Unspecified ethernet device|
|ETHERNET\_DEVICE\_EXPANSION|1|Ethernet port located on the expansion connector|

**Parent topic:** [InterconnectConfig \(C++\)](../../summary_pages/InterconnectConfig.md)

