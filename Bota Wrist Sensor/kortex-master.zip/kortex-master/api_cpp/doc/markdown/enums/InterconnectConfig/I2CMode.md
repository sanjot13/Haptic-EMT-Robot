# enum I2CMode

## Overview / Purpose

Enumeration I2CMode

|Enumerator|Value|Description|
|----------|-----|-----------|
|I2C\_MODE\_UNSPECIFIED|0|Unspecified I2C mode|
|I2C\_MODE\_STANDARD|1|Standard mode|
|I2C\_MODE\_FAST|2|Fast mode|
|I2C\_MODE\_FAST\_PLUS|3|Fast plus mode|

**Parent topic:** [InterconnectConfig \(C++\)](../../summary_pages/InterconnectConfig.md)

