# enum GPIOValue

## Overview / Purpose

Enumeration GPIOValue

|Enumerator|Value|Description|
|----------|-----|-----------|
|GPIO\_VALUE\_UNSPECIFIED|0|Unspecified GPIO value|
|GPIO\_VALUE\_LOW|1|Low|
|GPIO\_VALUE\_HIGH|2|High|

**Parent topic:** [InterconnectConfig \(C++\)](../../summary_pages/InterconnectConfig.md)

