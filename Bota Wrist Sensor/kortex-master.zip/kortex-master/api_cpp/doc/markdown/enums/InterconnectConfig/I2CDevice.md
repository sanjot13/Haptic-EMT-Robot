# enum I2CDevice

## Overview / Purpose

Enumeration I2CDevice

|Enumerator|Value|Description|
|----------|-----|-----------|
|I2C\_DEVICE\_UNSPECIFIED|0|Unspecified I2C device|
|I2C\_DEVICE\_EXPANSION|1|I2C device located on the expansion connector|

**Parent topic:** [InterconnectConfig \(C++\)](../../summary_pages/InterconnectConfig.md)

