# enum Sensor

## Overview / Purpose

Enumeration Sensor

|Enumerator|Value|Description|
|----------|-----|-----------|
|SENSOR\_UNSPECIFIED|0|Unspecified Sensor|
|SENSOR\_COLOR|1|Select the Vision module color sensor|
|SENSOR\_DEPTH|2|Select the Vision module depth sensor|

**Parent topic:** [VisionConfig \(C++\)](../../summary_pages/VisionConfig.md)

